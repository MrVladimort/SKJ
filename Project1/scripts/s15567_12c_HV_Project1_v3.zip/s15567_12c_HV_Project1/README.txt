Everything is going well
HTTP server: localhost:8080 - done
wszystko jest zrealizowane zgodnie z opisem zadania
do agentow jest mozliwosc wysylania polecen: clk, agn + address agenta, net, syn, del, die
do monitora getHttp, postHttp (synchronize, delete) przez url, syn + address agenta, die + address agenta, agn + address agenta, net
Monitor - done
Agent - done
